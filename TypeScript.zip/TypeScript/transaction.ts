export interface Transaction{

    id: number;
    TransactionDate: Date ;
    detail:string;
    value:number;
    
}