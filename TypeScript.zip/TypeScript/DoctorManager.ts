import {Doctor} from './Doctor' ;
import {Transaction} from './transaction' ; 
//using REST parameter
 function showDoctors (doctorList: Doctor[]) :void {
 //using Arrow Function

 doctorList.forEach(eachDoctor => {

    console.log(eachDoctor.toString())
 })

 };

 function showTransaction(txn:Transaction) {

console.log(txn.detail);
console.log(txn.id);


 }

 const ram = new Doctor(101, 'ramesh','ent') ;
 const shyam = new  Doctor(101, 'shyam','eye') ;

 const  docList = [ram,shyam] ;
 showDoctors(docList);
 const tx1:Transaction = {id:102, detail:'sugar test',value:1900,  TransactionDate: new Date()};
  console.log(tx1);

 