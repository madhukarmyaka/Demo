"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Doctor_1 = require("./Doctor");
//using REST parameter
function showDoctors(doctorList) {
    //using Arrow Function
    doctorList.forEach(eachDoctor => {
        console.log(eachDoctor.toString());
    });
}
;
function showTransaction(txn) {
    console.log(txn.detail);
    console.log(txn.id);
}
const ram = new Doctor_1.Doctor(101, 'ramesh', 'ent');
const shyam = new Doctor_1.Doctor(101, 'shyam', 'eye');
const docList = [ram, shyam];
showDoctors(docList);
const tx1 = { id: 102, detail: 'sugar test', value: 1900, TransactionDate: new Date() };
console.log(tx1);
