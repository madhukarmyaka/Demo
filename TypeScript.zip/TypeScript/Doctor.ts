export class Doctor{
    
    public id:number;
    public name:string;
    public specilization:string ; 
    constructor(id:number, name:string, specilization:string) {

    this.id = id;
    this.name = name;
    this.specilization = specilization; 

}

toString():string {

    //using template literals

    return `${this.id}, ${this.name}, ${this.specilization}` ;

}

}