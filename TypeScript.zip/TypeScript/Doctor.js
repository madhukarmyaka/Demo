"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class Doctor {
    constructor(id, name, specilization) {
        this.id = id;
        this.name = name;
        this.specilization = specilization;
    }
    toString() {
        //using template literals
        return `${this.id}, ${this.name}, ${this.specilization}`;
    }
}
exports.Doctor = Doctor;
