export interface Hospital {
    id: number;
    hospitalName: string;
    phone: number;

}
