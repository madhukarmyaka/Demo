import { Component, OnInit } from '@angular/core';
import { Hospital } from '../hospital';
import { MedBuddyAPIService } from '../med-buddy-api.service';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {
  hospitalList: Hospital[] ;
  constructor(private service: MedBuddyAPIService) {

   // this.hospital = {id: 101, hospitalName: 'Care Hospital', phone: 1234650} ;

   }

  ngOnInit() {
    // subscribe has the parameter of observer, which is hospital list
 this.service.findAllHospitals().subscribe(data => this.hospitalList = data) ;

  }

}
