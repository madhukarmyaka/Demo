import { TestBed, inject } from '@angular/core/testing';

import { MedBuddyAPIService } from './med-buddy-api.service';

describe('MedBuddyAPIService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [MedBuddyAPIService]
    });
  });

  it('should be created', inject([MedBuddyAPIService], (service: MedBuddyAPIService) => {
    expect(service).toBeTruthy();
  }));
});
