export interface Doctor {
}
