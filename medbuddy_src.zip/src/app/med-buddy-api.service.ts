import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Hospital } from './hospital';

@Injectable({
  providedIn: 'root'
})
export class MedBuddyAPIService {

  constructor(private http: HttpClient) {}

  findAllHospitals(): Observable<Hospital[]> {
    return this.http.get <Hospital[]>('http://localhost:3000/hosiptials');

  }

  }



